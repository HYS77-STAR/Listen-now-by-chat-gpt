package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RedPrimary = Color(0xFFDC2626) // red-600
val BlackBackground = Color(0xFF000000)
val Neutral900 = Color(0xFF171717)
val Neutral800 = Color(0xFF262626)
val Neutral700 = Color(0xFF404040)
val Neutral600 = Color(0xFF525252)
val Neutral500 = Color(0xFF737373)
val Neutral400 = Color(0xFFA3A3A3)
val White = Color(0xFFFFFFFF)

// Light theme colors
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF5F5F5)
val LightSurfaceVariant = Color(0xFFE5E5E5)
val LightText = Color(0xFF000000)
val LightTextSecondary = Color(0xFF525252)
