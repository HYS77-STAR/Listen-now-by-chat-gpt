package com.example.ui.folders

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.MainViewModel

@Composable
fun FoldersScreen(navController: NavController, viewModel: MainViewModel) {
    val folders by viewModel.folders.collectAsState()
    
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        itemsIndexed(folders, key = { _, item -> item.path }) { index, folder ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { navController.navigate("folder/${java.net.URLEncoder.encode(folder.path, "UTF-8")}") }
                    .padding(16.dp)
            ) {
                // Drag Handle
                Column(
                    modifier = Modifier.padding(end = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Box(modifier = Modifier.height(2.dp).width(16.dp).background(MaterialTheme.colorScheme.onSurfaceVariant))
                    Box(modifier = Modifier.height(2.dp).width(16.dp).background(MaterialTheme.colorScheme.onSurfaceVariant))
                }
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = folder.name,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = folder.path,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                IconButton(onClick = { viewModel.hideFolder(folder) }) {
                    Icon(
                        painter = painterResource(android.R.drawable.ic_menu_close_clear_cancel),
                        contentDescription = "Hide",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Divider(color = MaterialTheme.colorScheme.surfaceVariant)
        }
    }
}
