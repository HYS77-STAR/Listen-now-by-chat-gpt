package com.example.ui.playlists

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.MainViewModel

@Composable
fun PlaylistsScreen(navController: NavController, viewModel: MainViewModel) {
    val playlists by viewModel.playlists.collectAsState()
    
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        itemsIndexed(playlists, key = { _, item -> item.id }) { index, playlist ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { navController.navigate("playlist/${playlist.id}") }
                    .padding(16.dp)
            ) {
                // Drag Handle
                Column(
                    modifier = Modifier.padding(end = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Box(modifier = Modifier.height(2.dp).width(16.dp).background(MaterialTheme.colorScheme.onSurfaceVariant))
                    Box(modifier = Modifier.height(2.dp).width(16.dp).background(MaterialTheme.colorScheme.onSurfaceVariant))
                }
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = playlist.name,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                
                IconButton(onClick = { viewModel.deletePlaylist(playlist.id) }) {
                    Icon(
                        painter = painterResource(android.R.drawable.ic_menu_delete),
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Divider(color = MaterialTheme.colorScheme.surfaceVariant)
        }
    }
}
