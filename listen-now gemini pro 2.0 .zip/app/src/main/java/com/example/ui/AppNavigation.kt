package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.MainViewModel
import com.example.ui.folders.FoldersScreen
import com.example.ui.folders.FolderDetailScreen
import com.example.ui.playlists.PlaylistsScreen
import com.example.ui.playlists.PlaylistDetailScreen
import com.example.ui.player.PlayerScreen
import com.example.ui.settings.PinScreen

@Composable
fun AppNavigation(
    navController: NavHostController,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = "pin",
        modifier = modifier
    ) {
        composable("pin") {
            PinScreen(onSuccess = { navController.navigate("home") { popUpTo("pin") { inclusive = true } } })
        }
        composable("home") {
            HomeScreen(navController, viewModel)
        }
        composable("folder/{path}") { backStackEntry ->
            val path = backStackEntry.arguments?.getString("path") ?: return@composable
            FolderDetailScreen(path, navController, viewModel)
        }
        composable("playlist/{id}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: return@composable
            PlaylistDetailScreen(id, navController, viewModel)
        }
        composable("player") {
            PlayerScreen(navController, viewModel.playbackController)
        }
    }
}
