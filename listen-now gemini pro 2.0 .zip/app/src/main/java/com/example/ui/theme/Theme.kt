package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = RedPrimary,
    onPrimary = White,
    background = BlackBackground,
    onBackground = White,
    surface = Neutral900,
    onSurface = White,
    surfaceVariant = Neutral800,
    onSurfaceVariant = Neutral400,
    secondary = Neutral800,
    onSecondary = White,
    tertiary = Neutral700,
    onTertiary = White,
)

private val LightColorScheme = lightColorScheme(
    primary = RedPrimary,
    onPrimary = White,
    background = LightBackground,
    onBackground = LightText,
    surface = LightSurface,
    onSurface = LightText,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    secondary = LightSurfaceVariant,
    onSecondary = LightText,
    tertiary = Neutral400,
    onTertiary = LightText,
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color to enforce our geometric theme
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
