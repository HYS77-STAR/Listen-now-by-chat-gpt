package com.example.ui.playlists

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.example.MainViewModel
import com.example.ui.components.TrackItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistDetailScreen(playlistId: Long, navController: NavController, viewModel: MainViewModel) {
    val tracks by viewModel.getPlaylistTracks(playlistId).collectAsState()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Playlist") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_revert), contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(paddingValues)
        ) {
            itemsIndexed(tracks, key = { _, item -> item.id }) { index, track ->
                TrackItem(
                    index = index + 1,
                    audio = track,
                    onClick = {
                        viewModel.playbackController.playAudioList(tracks, index)
                    },
                    onMenuClick = {
                        // TODO: Context menu
                    }
                )
            }
        }
    }
}
