package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext
import com.example.data.AppPreferences

@Composable
fun PinScreen(onSuccess: () -> Unit) {
    val context = LocalContext.current
    val appPreferences = remember { AppPreferences(context) }
    val isPinEnabled by appPreferences.isPinEnabled.collectAsState(initial = false)
    val savedPin by appPreferences.pinCode.collectAsState(initial = null)
    
    var enteredPin by remember { mutableStateOf("") }
    
    // If PIN is not enabled, automatically proceed
    LaunchedEffect(isPinEnabled) {
        if (!isPinEnabled) {
            onSuccess()
        }
    }

    if (isPinEnabled) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Enter PIN", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(32.dp))
            
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                for (i in 0 until 4) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(if (i < enteredPin.length) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Keypad
            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("", "0", "DEL")
            )

            for (row in keys) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    for (key in row) {
                        if (key.isEmpty()) {
                            Spacer(modifier = Modifier.size(64.dp))
                        } else {
                            TextButton(
                                onClick = {
                                    if (key == "DEL") {
                                        if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                    } else {
                                        if (enteredPin.length < 4) enteredPin += key
                                        if (enteredPin.length == 4) {
                                            if (enteredPin == savedPin) {
                                                onSuccess()
                                            } else {
                                                enteredPin = ""
                                                // Handle error feedback
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier.size(64.dp)
                            ) {
                                Text(text = key, fontSize = 24.sp, color = MaterialTheme.colorScheme.onBackground)
                            }
                        }
                    }
                }
            }
        }
    }
}
