package com.example.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.service.PlaybackController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(navController: NavController, playbackController: PlaybackController) {
    val currentAudio by playbackController.currentAudio.collectAsState()
    val isPlaying by playbackController.isPlaying.collectAsState()
    val currentPosition by playbackController.currentPosition.collectAsState()
    val sleepTimerRemaining by playbackController.sleepTimerRemaining.collectAsState()

    var showSleepTimerDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(painterResource(android.R.drawable.ic_menu_revert), contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            
            Spacer(modifier = Modifier.weight(1f))

            // Central Circular Artwork Module
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Text("LN", style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Track Details
            Text(
                text = currentAudio?.title ?: "No Track Selected",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = currentAudio?.artist ?: "Unknown Artist",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(32.dp))
            
            // Progress
            val duration = currentAudio?.duration ?: 0L
            Slider(
                value = currentPosition.toFloat(),
                onValueChange = { playbackController.seekTo(it.toLong()) },
                valueRange = 0f..(if (duration > 0) duration.toFloat() else 1f),
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                    inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { playbackController.toggleShuffle() }) {
                    Icon(painterResource(android.R.drawable.ic_menu_sort_by_size), contentDescription = "Shuffle")
                }
                IconButton(onClick = { playbackController.skipToPrevious() }) {
                    Icon(painterResource(android.R.drawable.ic_media_previous), contentDescription = "Previous")
                }
                
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = { playbackController.togglePlayPause() }) {
                        Icon(
                            painter = painterResource(if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
                            contentDescription = "Play/Pause",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
                
                IconButton(onClick = { playbackController.skipToNext() }) {
                    Icon(painterResource(android.R.drawable.ic_media_next), contentDescription = "Next")
                }
                IconButton(onClick = { showSleepTimerDialog = true }) {
                    Icon(painterResource(android.R.drawable.ic_menu_recent_history), contentDescription = "Sleep Timer")
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            if (sleepTimerRemaining != null) {
                Text(
                    text = "Sleep Timer: ${sleepTimerRemaining!! / 60000}m",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }

    if (showSleepTimerDialog) {
        AlertDialog(
            onDismissRequest = { showSleepTimerDialog = false },
            title = { Text("Sleep Timer") },
            text = { Text("Set the sleep timer duration in minutes") },
            confirmButton = {
                TextButton(onClick = {
                    playbackController.startSleepTimer(30) // Default 30 min for brevity
                    showSleepTimerDialog = false
                }) {
                    Text("30 Min")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    playbackController.stopSleepTimer()
                    showSleepTimerDialog = false
                }) {
                    Text("Off")
                }
            }
        )
    }
}
