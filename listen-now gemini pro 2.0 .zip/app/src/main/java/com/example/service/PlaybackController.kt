package com.example.service

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import androidx.media3.common.C
import com.example.data.AudioItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PlaybackController(context: Context) {
    private var controller: MediaController? = null
    
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()
    
    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition = _currentPosition.asStateFlow()
    
    private val _currentAudio = MutableStateFlow<AudioItem?>(null)
    val currentAudio = _currentAudio.asStateFlow()
    
    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode = _repeatMode.asStateFlow()
    
    private val _shuffleMode = MutableStateFlow(false)
    val shuffleMode = _shuffleMode.asStateFlow()

    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    
    private var sleepTimerJob: Job? = null
    private val _sleepTimerRemaining = MutableStateFlow<Long?>(null)
    val sleepTimerRemaining = _sleepTimerRemaining.asStateFlow()

    private var currentPlaylist: List<AudioItem> = emptyList()

    init {
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener(
            {
                controller = controllerFuture.get()
                controller?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _isPlaying.value = isPlaying
                        if (isPlaying) {
                            startProgressTracking()
                        } else {
                            stopProgressTracking()
                        }
                    }

                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        if (mediaItem != null) {
                            val id = mediaItem.mediaId.toLongOrNull()
                            _currentAudio.value = currentPlaylist.find { it.id == id }
                        } else {
                            _currentAudio.value = null
                        }
                    }
                    
                    override fun onRepeatModeChanged(repeatMode: Int) {
                        _repeatMode.value = repeatMode
                    }

                    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                        _shuffleMode.value = shuffleModeEnabled
                    }
                })
            },
            MoreExecutors.directExecutor()
        )
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                controller?.let {
                    _currentPosition.value = it.currentPosition
                }
                delay(1000)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    fun playAudioList(audioList: List<AudioItem>, startIndex: Int = 0) {
        currentPlaylist = audioList
        val mediaItems = audioList.map { audio ->
            MediaItem.Builder()
                .setMediaId(audio.id.toString())
                .setUri(audio.data)
                .build()
        }
        controller?.run {
            setMediaItems(mediaItems, startIndex, C.TIME_UNSET)
            prepare()
            play()
        }
    }
    
    fun syncQueueOrder(audioList: List<AudioItem>) {
        val currentAudioId = _currentAudio.value?.id
        currentPlaylist = audioList
        val mediaItems = audioList.map { audio ->
            MediaItem.Builder()
                .setMediaId(audio.id.toString())
                .setUri(audio.data)
                .build()
        }
        controller?.run {
            val wasPlaying = isPlaying
            val pos = currentPosition
            val newIndex = audioList.indexOfFirst { it.id == currentAudioId }.takeIf { it >= 0 } ?: 0
            
            setMediaItems(mediaItems, newIndex, pos)
            prepare()
            if (wasPlaying) play()
        }
    }

    fun togglePlayPause() {
        controller?.run {
            if (isPlaying) {
                pause()
            } else {
                play()
            }
        }
    }

    fun skipToNext() {
        controller?.seekToNext()
    }

    fun skipToPrevious() {
        controller?.seekToPrevious()
    }

    fun toggleRepeat() {
        controller?.run {
            repeatMode = when (repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun toggleShuffle() {
        controller?.run {
            shuffleModeEnabled = !shuffleModeEnabled
        }
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerRemaining.value = null
            return
        }
        
        sleepTimerJob = scope.launch {
            var remaining = minutes * 60 * 1000L
            while (remaining > 0) {
                _sleepTimerRemaining.value = remaining
                delay(1000)
                remaining -= 1000
                
                // Fade out in last 3 seconds
                if (remaining <= 3000 && remaining > 0) {
                    val volume = (remaining / 3000f)
                    controller?.volume = volume
                }
            }
            
            _sleepTimerRemaining.value = null
            controller?.pause()
            controller?.volume = 1f // Reset volume for next time
        }
    }

    fun stopSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerRemaining.value = null
        controller?.volume = 1f
    }
}
