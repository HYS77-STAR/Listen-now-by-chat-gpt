package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AudioItem
import com.example.data.AudioRepository
import com.example.data.FolderItem
import com.example.data.Playlist
import com.example.data.PlaylistTrack
import com.example.service.PlaybackController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: AudioRepository,
    val playbackController: PlaybackController
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _sortOrder = MutableStateFlow(SortOrder.CUSTOM)
    val sortOrder = _sortOrder.asStateFlow()
    
    val folders = combine(repository.folders, _sortOrder) { list, order ->
        when (order) {
            SortOrder.CHRONOLOGICAL_ASC -> list.sortedBy { it.dateAdded }
            SortOrder.CHRONOLOGICAL_DESC -> list.sortedByDescending { it.dateAdded }
            else -> list.sortedBy { it.customOrder }
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val playlists = combine(repository.playlists, _sortOrder) { list, order ->
        when (order) {
            SortOrder.CHRONOLOGICAL_ASC -> list.sortedBy { it.createdAt }
            SortOrder.CHRONOLOGICAL_DESC -> list.sortedByDescending { it.createdAt }
            else -> list.sortedBy { it.customOrder }
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun scanMedia() {
        viewModelScope.launch {
            repository.scanMedia()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOrder(order: SortOrder) {
        _sortOrder.value = order
    }

    fun getAudioForFolder(folderPath: String): StateFlow<List<AudioItem>> {
        return combine(repository.getAudioItemsForFolder(folderPath), _sortOrder, _searchQuery) { list, order, query ->
            var result = list
            if (query.isNotBlank()) {
                result = list.filter { it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true) }
            } else {
                result = when (order) {
                    SortOrder.CHRONOLOGICAL_ASC -> list.sortedBy { it.dateAdded }
                    SortOrder.CHRONOLOGICAL_DESC -> list.sortedByDescending { it.dateAdded }
                    else -> list.sortedBy { it.customOrder }
                }
            }
            result
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    fun hideFolder(folder: FolderItem) {
        viewModelScope.launch {
            repository.hideFolder(folder)
        }
    }
    
    fun hideAudio(audio: AudioItem) {
        viewModelScope.launch {
            repository.hideAudio(audio)
        }
    }

    fun reorderFolders(from: Int, to: Int, list: List<FolderItem>) {
        val mutableList = list.toMutableList()
        val item = mutableList.removeAt(from)
        mutableList.add(to, item)
        viewModelScope.launch {
            repository.updateFolderOrder(mutableList)
        }
    }

    fun reorderAudio(from: Int, to: Int, list: List<AudioItem>) {
        val mutableList = list.toMutableList()
        val item = mutableList.removeAt(from)
        mutableList.add(to, item)
        viewModelScope.launch {
            repository.updateAudioOrder(mutableList)
            playbackController.syncQueueOrder(mutableList)
        }
    }
    
    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name)
        }
    }
    
    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(id)
        }
    }

    fun getPlaylistTracks(playlistId: Long): StateFlow<List<AudioItem>> {
        return repository.getTracksForPlaylist(playlistId)
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }
}

enum class SortOrder {
    CUSTOM, CHRONOLOGICAL_ASC, CHRONOLOGICAL_DESC
}
