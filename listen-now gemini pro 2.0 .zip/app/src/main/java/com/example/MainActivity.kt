package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.data.AppDatabase
import com.example.data.AudioRepository
import com.example.service.PlaybackController
import com.example.ui.AppNavigation
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.material3.Text

class MainActivity : ComponentActivity() {
  @OptIn(ExperimentalPermissionsApi::class)
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    val database = AppDatabase.getDatabase(this)
    val repository = AudioRepository(database.audioDao(), this)
    val playbackController = PlaybackController(this)
    
    setContent {
      val viewModel: MainViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
          factory = object : androidx.lifecycle.ViewModelProvider.Factory {
              override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                  return MainViewModel(repository, playbackController) as T
              }
          }
      )
      
      val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          Manifest.permission.READ_MEDIA_AUDIO
      } else {
          Manifest.permission.READ_EXTERNAL_STORAGE
      }
      
      val permissionState = rememberPermissionState(permission = permission)
      
      LaunchedEffect(Unit) {
          if (!permissionState.status.isGranted) {
              permissionState.launchPermissionRequest()
          } else {
              viewModel.scanMedia()
          }
      }
      
      LaunchedEffect(permissionState.status.isGranted) {
          if (permissionState.status.isGranted) {
              viewModel.scanMedia()
          }
      }

      MyApplicationTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (permissionState.status.isGranted) {
                val navController = rememberNavController()
                AppNavigation(navController = navController, viewModel = viewModel)
            } else {
                Text("Storage permission is required to access audio files.", modifier = Modifier.fillMaxSize())
            }
        }
      }
    }
  }
}

