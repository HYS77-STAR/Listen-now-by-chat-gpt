package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "folder_items")
data class FolderItem(
    @PrimaryKey val path: String,
    val name: String,
    val isHidden: Boolean = false,
    val customOrder: Int = 0,
    val dateAdded: Long = 0L // To support chronological sort
)
