package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audio_items")
data class AudioItem(
    @PrimaryKey val id: Long, // MediaStore ID
    val title: String,
    val artist: String,
    val duration: Long, // in ms
    val data: String, // Absolute file path
    val folderPath: String, // Parent folder path
    val dateAdded: Long,
    val isHidden: Boolean = false,
    val customOrder: Int = 0
)
