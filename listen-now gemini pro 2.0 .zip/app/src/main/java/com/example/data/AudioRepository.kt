package com.example.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlinx.coroutines.flow.Flow

class AudioRepository(private val audioDao: AudioDao, private val context: Context) {
    
    val folders = audioDao.getFolders()
    val playlists = audioDao.getPlaylists()

    fun getAudioItemsForFolder(folderPath: String) = audioDao.getAudioItemsForFolder(folderPath)
    fun searchAudio(query: String) = audioDao.searchAudioItems(query)
    fun getTracksForPlaylist(playlistId: Long) = audioDao.getTracksForPlaylist(playlistId)

    suspend fun scanMedia() = withContext(Dispatchers.IO) {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        val cursor = context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            sortOrder
        )

        val audioItems = mutableListOf<AudioItem>()
        val folderPaths = mutableSetOf<String>()

        cursor?.use {
            val idColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateAddedColumn = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            while (it.moveToNext()) {
                val id = it.getLong(idColumn)
                val title = it.getString(titleColumn) ?: "Unknown Title"
                val artist = it.getString(artistColumn) ?: "Unknown Artist"
                val duration = it.getLong(durationColumn)
                val data = it.getString(dataColumn)
                val dateAdded = it.getLong(dateAddedColumn)

                if (data != null) {
                    val file = File(data)
                    val parentFile = file.parentFile
                    if (parentFile != null && parentFile.exists()) {
                        val folderPath = parentFile.absolutePath
                        val validExtensions = listOf("mp3", "wav", "flac", "m4a", "aac")
                        if (validExtensions.any { ext -> data.endsWith(ext, ignoreCase = true) }) {
                            folderPaths.add(folderPath)
                            audioItems.add(
                                AudioItem(
                                    id = id,
                                    title = title,
                                    artist = artist,
                                    duration = duration,
                                    data = data,
                                    folderPath = folderPath,
                                    dateAdded = dateAdded
                                )
                            )
                        }
                    }
                }
            }
        }

        val folderItems = folderPaths.map { path ->
            val file = File(path)
            FolderItem(
                path = path,
                name = file.name,
                dateAdded = System.currentTimeMillis() // Or try to get dir creation date
            )
        }

        // Insert new items, ignoring existing ones to preserve customOrder and isHidden
        audioDao.insertAudioItems(audioItems)
        audioDao.insertFolderItems(folderItems)

        // Clean up orphaned items
        audioDao.deleteOrphanedAudioItems(audioItems.map { it.id })
        audioDao.deleteOrphanedFolderItems(folderItems.map { it.path })
    }

    suspend fun hideFolder(folder: FolderItem) {
        audioDao.updateFolderItem(folder.copy(isHidden = true))
    }

    suspend fun hideAudio(audio: AudioItem) {
        audioDao.updateAudioItem(audio.copy(isHidden = true))
    }
    
    suspend fun updateFolderOrder(folders: List<FolderItem>) {
        val updated = folders.mapIndexed { index, folder -> folder.copy(customOrder = index) }
        audioDao.updateFolderItems(updated)
    }

    suspend fun updateAudioOrder(audioItems: List<AudioItem>) {
        val updated = audioItems.mapIndexed { index, item -> item.copy(customOrder = index) }
        audioDao.updateAudioItems(updated)
    }

    suspend fun updatePlaylistOrder(playlists: List<Playlist>) {
        val updated = playlists.mapIndexed { index, playlist -> playlist.copy(customOrder = index) }
        audioDao.updatePlaylists(updated)
    }
    
    suspend fun updatePlaylistTrackOrder(tracks: List<PlaylistTrack>) {
        val updated = tracks.mapIndexed { index, track -> track.copy(customOrder = index) }
        audioDao.updatePlaylistTracks(updated)
    }

    suspend fun createPlaylist(name: String) {
        audioDao.insertPlaylist(Playlist(name = name))
    }

    suspend fun deletePlaylist(id: Long) {
        audioDao.deletePlaylistAndTracks(id)
    }

    suspend fun addTrackToPlaylist(playlistId: Long, audioId: Long) {
        val raw = audioDao.getPlaylistTracksRaw(playlistId)
        val maxOrder = raw.maxOfOrNull { it.customOrder } ?: -1
        audioDao.insertPlaylistTrack(PlaylistTrack(playlistId = playlistId, audioId = audioId, customOrder = maxOrder + 1))
    }
}
