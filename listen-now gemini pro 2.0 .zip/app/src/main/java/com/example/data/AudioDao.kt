package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AudioDao {
    @Query("SELECT * FROM audio_items WHERE isHidden = 0 AND folderPath = :folderPath ORDER BY customOrder ASC, dateAdded DESC")
    fun getAudioItemsForFolder(folderPath: String): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio_items WHERE isHidden = 0 AND folderPath = :folderPath ORDER BY dateAdded ASC")
    fun getAudioItemsForFolderChronologicalAsc(folderPath: String): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio_items WHERE isHidden = 0 AND folderPath = :folderPath ORDER BY dateAdded DESC")
    fun getAudioItemsForFolderChronologicalDesc(folderPath: String): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio_items WHERE id = :id")
    suspend fun getAudioItemById(id: Long): AudioItem?

    @Query("SELECT * FROM audio_items WHERE isHidden = 0 AND title LIKE '%' || :query || '%'")
    fun searchAudioItems(query: String): Flow<List<AudioItem>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAudioItems(items: List<AudioItem>)

    @Update
    suspend fun updateAudioItem(item: AudioItem)

    @Update
    suspend fun updateAudioItems(items: List<AudioItem>)

    @Query("DELETE FROM audio_items WHERE id NOT IN (:validIds)")
    suspend fun deleteOrphanedAudioItems(validIds: List<Long>)

    // Folders
    @Query("SELECT * FROM folder_items WHERE isHidden = 0 ORDER BY customOrder ASC, dateAdded DESC")
    fun getFolders(): Flow<List<FolderItem>>

    @Query("SELECT * FROM folder_items WHERE isHidden = 0 ORDER BY dateAdded ASC")
    fun getFoldersChronologicalAsc(): Flow<List<FolderItem>>

    @Query("SELECT * FROM folder_items WHERE isHidden = 0 ORDER BY dateAdded DESC")
    fun getFoldersChronologicalDesc(): Flow<List<FolderItem>>

    @Query("SELECT * FROM folder_items WHERE path = :path")
    suspend fun getFolderByPath(path: String): FolderItem?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFolderItems(items: List<FolderItem>)

    @Update
    suspend fun updateFolderItem(item: FolderItem)

    @Update
    suspend fun updateFolderItems(items: List<FolderItem>)

    @Query("DELETE FROM folder_items WHERE path NOT IN (:validPaths)")
    suspend fun deleteOrphanedFolderItems(validPaths: List<String>)

    // Playlists
    @Query("SELECT * FROM playlists ORDER BY customOrder ASC, createdAt DESC")
    fun getPlaylists(): Flow<List<Playlist>>

    @Query("SELECT * FROM playlists ORDER BY createdAt ASC")
    fun getPlaylistsChronologicalAsc(): Flow<List<Playlist>>

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getPlaylistsChronologicalDesc(): Flow<List<Playlist>>

    @Insert
    suspend fun insertPlaylist(playlist: Playlist): Long

    @Update
    suspend fun updatePlaylist(playlist: Playlist)

    @Update
    suspend fun updatePlaylists(playlists: List<Playlist>)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun deletePlaylistTracks(playlistId: Long)

    @Transaction
    suspend fun deletePlaylistAndTracks(playlistId: Long) {
        deletePlaylist(playlistId)
        deletePlaylistTracks(playlistId)
    }

    // Playlist Tracks
    @Query("""
        SELECT a.* FROM audio_items a 
        INNER JOIN playlist_tracks pt ON a.id = pt.audioId 
        WHERE pt.playlistId = :playlistId AND a.isHidden = 0
        ORDER BY pt.customOrder ASC
    """)
    fun getTracksForPlaylist(playlistId: Long): Flow<List<AudioItem>>

    @Query("""
        SELECT a.* FROM audio_items a 
        INNER JOIN playlist_tracks pt ON a.id = pt.audioId 
        WHERE pt.playlistId = :playlistId AND a.isHidden = 0
    """)
    suspend fun getTracksForPlaylistSync(playlistId: Long): List<AudioItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistTrack(track: PlaylistTrack)

    @Update
    suspend fun updatePlaylistTracks(tracks: List<PlaylistTrack>)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND audioId = :audioId")
    suspend fun removeTrackFromPlaylist(playlistId: Long, audioId: Long)

    @Query("SELECT * FROM playlist_tracks WHERE playlistId = :playlistId ORDER BY customOrder ASC")
    suspend fun getPlaylistTracksRaw(playlistId: Long): List<PlaylistTrack>
}
