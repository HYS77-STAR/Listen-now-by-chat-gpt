package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "settings")

class AppPreferences(private val context: Context) {

    private val THEME_KEY = booleanPreferencesKey("is_dark_theme")
    private val PIN_KEY = stringPreferencesKey("app_pin")
    private val PIN_ENABLED_KEY = booleanPreferencesKey("is_pin_enabled")

    val isDarkTheme: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[THEME_KEY] ?: true // Default dark theme
    }

    val pinCode: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[PIN_KEY]
    }

    val isPinEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[PIN_ENABLED_KEY] ?: false
    }

    suspend fun setDarkTheme(isDark: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[THEME_KEY] = isDark
        }
    }

    suspend fun setPinCode(pin: String?) {
        context.dataStore.edit { preferences ->
            if (pin != null) {
                preferences[PIN_KEY] = pin
                preferences[PIN_ENABLED_KEY] = true
            } else {
                preferences.remove(PIN_KEY)
                preferences[PIN_ENABLED_KEY] = false
            }
        }
    }
}
