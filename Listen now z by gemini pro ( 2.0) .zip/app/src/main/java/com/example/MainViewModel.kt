package com.example

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.example.data.*
import com.example.service.AudioService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val audioFiles: List<AudioFile> = emptyList(),
    val hiddenFolders: Set<String> = emptySet(),
    val folderOrders: Map<String, Int> = emptyMap(),
    val audioOrders: Map<Long, Int> = emptyMap(),
    val folderSort: String = "DATE_DESC",
    val audioSort: String = "DATE_DESC",
    val isPlaying: Boolean = false,
    val currentlyPlayingId: Long? = null,
    val currentPosition: Long = 0,
    val duration: Long = 0
)

class MainViewModel(
    private val scanner: MediaScanner,
    private val appDao: AppDao,
    private val settingsRepo: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState = _uiState.asStateFlow()
    
    private var controllerFuture: ListenableFuture<MediaController>? = null
    var mediaController: MediaController? = null
        private set

    init {
        viewModelScope.launch {
            combine(
                settingsRepo.folderSort,
                settingsRepo.audioSort
            ) { fSort, aSort ->
                _uiState.update { it.copy(folderSort = fSort, audioSort = aSort) }
            }.collect()
        }
        
        viewModelScope.launch {
            appDao.getAllFolders().collect { folders ->
                val hidden = folders.filter { it.isHidden }.map { it.path }.toSet()
                val orders = folders.associate { it.path to it.customOrder }
                _uiState.update { it.copy(hiddenFolders = hidden, folderOrders = orders) }
            }
        }
        
        viewModelScope.launch {
            appDao.getAllAudio().collect { audio ->
                val orders = audio.associate { it.id to it.customOrder }
                _uiState.update { it.copy(audioOrders = orders) }
            }
        }
    }

    fun initController(context: Context) {
        if (controllerFuture == null) {
            val sessionToken = SessionToken(context, ComponentName(context, AudioService::class.java))
            controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
            controllerFuture?.addListener({
                mediaController = controllerFuture?.get()
                mediaController?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _uiState.update { it.copy(isPlaying = isPlaying) }
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        val id = mediaItem?.mediaId?.toLongOrNull()
                        _uiState.update { it.copy(
                            currentlyPlayingId = id,
                            duration = mediaController?.duration?.coerceAtLeast(0) ?: 0
                        ) }
                    }
                })
            }, androidx.core.content.ContextCompat.getMainExecutor(context))
        }
    }

    fun loadAudio() {
        viewModelScope.launch {
            val audio = scanner.scanAudioFiles()
            _uiState.update { it.copy(audioFiles = audio) }
        }
    }

    fun playAudio(audioFile: AudioFile) {
        val controller = mediaController ?: return
        val mediaItem = MediaItem.Builder()
            .setMediaId(audioFile.id.toString())
            .setUri(audioFile.path)
            .build()
        controller.setMediaItem(mediaItem)
        controller.prepare()
        controller.play()
    }
    
    fun togglePlayPause() {
        val controller = mediaController ?: return
        if (controller.isPlaying) {
            controller.pause()
        } else {
            controller.play()
        }
    }

    fun hideFolder(folderName: String) {
        viewModelScope.launch {
            appDao.insertFolder(FolderEntity(path = folderName, customOrder = 0, isHidden = true))
        }
    }

    fun setFolderSort(sort: String) {
        viewModelScope.launch { settingsRepo.setFolderSort(sort) }
    }

    fun setAudioSort(sort: String) {
        viewModelScope.launch { settingsRepo.setAudioSort(sort) }
    }
    
    fun saveFoldersOrder(folders: List<String>) {
        viewModelScope.launch {
            val entities = folders.mapIndexed { index, path ->
                val isHidden = _uiState.value.hiddenFolders.contains(path)
                FolderEntity(path = path, customOrder = index, isHidden = isHidden)
            }
            appDao.insertFolders(entities)
        }
    }

    fun saveAudioOrder(audioFiles: List<AudioFile>) {
        viewModelScope.launch {
            val entities = audioFiles.mapIndexed { index, audio ->
                AudioEntity(id = audio.id, customOrder = index)
            }
            appDao.insertAudioList(entities)
        }
    }
}
