package com.example.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AudioService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var exoPlayer: ExoPlayer? = null
    
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var sleepTimerJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .build()
        exoPlayer = player
        
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        sleepTimerJob?.cancel()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
    
    // Command actions can be done via custom layout or static singleton for simplicity in this constrained environment
    companion object {
        var sleepTimerEndTimeMs: Long? = null
        private var instance: AudioService? = null
        
        fun setSleepTimer(minutes: Int) {
            val service = instance ?: return
            service.sleepTimerJob?.cancel()
            if (minutes <= 0) {
                sleepTimerEndTimeMs = null
                return
            }
            sleepTimerEndTimeMs = System.currentTimeMillis() + minutes * 60_000L
            service.sleepTimerJob = service.serviceScope.launch {
                val delayTime = minutes * 60_000L
                delay(delayTime)
                sleepTimerEndTimeMs = null
                service.exoPlayer?.stop()
                service.exoPlayer?.clearMediaItems()
            }
        }
        
        fun cancelSleepTimer() {
            instance?.sleepTimerJob?.cancel()
            sleepTimerEndTimeMs = null
        }
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        instance = this
        return super.onStartCommand(intent, flags, startId)
    }
}
