package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.*
import com.example.ui.screens.*
import com.example.ui.theme.ListenNowTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private lateinit var settingsRepo: SettingsRepository
    private lateinit var appDao: AppDao
    private lateinit var scanner: MediaScanner

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                // permission granted
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        settingsRepo = SettingsRepository(this)
        appDao = AppDatabase.getDatabase(this).appDao()
        scanner = MediaScanner(this)

        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(perm)
        }

        setContent {
            val themeStr by settingsRepo.theme.collectAsState(initial = "DARK")
            val darkTheme = when(themeStr) {
                "DARK" -> true
                "LIGHT" -> false
                else -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            
            ListenNowTheme(darkTheme = darkTheme) {
                AppNavigation(
                    settingsRepo = settingsRepo,
                    appDao = appDao,
                    scanner = scanner,
                    context = this
                )
            }
        }
    }
}

@Composable
fun AppNavigation(
    settingsRepo: SettingsRepository,
    appDao: AppDao,
    scanner: MediaScanner,
    context: android.content.Context
) {
    val navController = rememberNavController()
    
    val viewModel: MainViewModel = viewModel(
        factory = object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return MainViewModel(scanner, appDao, settingsRepo) as T
            }
        }
    )

    LaunchedEffect(Unit) {
        viewModel.initController(context)
        viewModel.loadAudio()
    }
    
    var showSplash by remember { mutableStateOf(true) }
    
    if (showSplash) {
        SplashScreen(onFinished = { showSplash = false })
        return
    }
    
    val lockEnabled by settingsRepo.lockEnabled.collectAsState(initial = false)
    val pin by settingsRepo.pin.collectAsState(initial = null)
    var isUnlocked by remember { mutableStateOf(false) }
    
    if (lockEnabled && !isUnlocked && pin != null) {
        LockScreen(
            correctPin = pin!!,
            onUnlock = { isUnlocked = true }
        )
        return
    }

    NavHost(navController = navController, startDestination = "folders") {
        composable("folders") {
            FoldersScreen(viewModel, navController, settingsRepo)
        }
        composable("audio_list/{folderName}") { backStackEntry ->
            val folderName = backStackEntry.arguments?.getString("folderName") ?: return@composable
            AudioListScreen(folderName, viewModel, navController)
        }
        composable("player") {
            PlayerScreen(viewModel, navController)
        }
    }
}

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    var textVisible by remember { mutableStateOf(false) }
    
    LaunchedEffect(Unit) {
        delay(300)
        textVisible = true
        delay(1200)
        textVisible = false
        delay(500)
        onFinished()
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visible = textVisible,
            enter = androidx.compose.animation.fadeIn(animationSpec = androidx.compose.animation.core.tween(1200)),
            exit = androidx.compose.animation.fadeOut(animationSpec = androidx.compose.animation.core.tween(500))
        ) {
            Text(
                text = "Listen Now",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
