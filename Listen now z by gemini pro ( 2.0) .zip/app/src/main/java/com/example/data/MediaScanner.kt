package com.example.data

import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AudioFile(
    val id: Long,
    val title: String,
    val path: String,
    val folderName: String,
    val dateAdded: Long,
    val duration: Long
)

class MediaScanner(private val context: Context) {
    suspend fun scanAudioFiles(): List<AudioFile> = withContext(Dispatchers.IO) {
        val audioList = mutableListOf<AudioFile>()
        
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DURATION
        )
        
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            null
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateAddedColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            
            while (cursor.moveToNext()) {
                val path = cursor.getString(dataColumn) ?: continue
                // valid audio formats: MP3, WAV, FLAC, AAC, OGG, M4A
                val ext = path.substringAfterLast('.').lowercase()
                if (ext !in listOf("mp3", "wav", "flac", "aac", "ogg", "m4a")) continue
                
                val folderName = path.substringBeforeLast('/').substringAfterLast('/')
                
                audioList.add(
                    AudioFile(
                        id = cursor.getLong(idColumn),
                        title = cursor.getString(titleColumn) ?: "Unknown",
                        path = path,
                        folderName = folderName,
                        dateAdded = cursor.getLong(dateAddedColumn),
                        duration = cursor.getLong(durationColumn)
                    )
                )
            }
        }
        audioList
    }
}
