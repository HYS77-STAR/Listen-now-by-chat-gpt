package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    companion object {
        val PIN = stringPreferencesKey("pin")
        val LOCK_ENABLED = booleanPreferencesKey("lock_enabled")
        val THEME = stringPreferencesKey("theme")
        val FOLDER_SORT = stringPreferencesKey("folder_sort")
        val AUDIO_SORT = stringPreferencesKey("audio_sort")
    }

    val pin: Flow<String?> = context.dataStore.data.map { it[PIN] }
    val lockEnabled: Flow<Boolean> = context.dataStore.data.map { it[LOCK_ENABLED] ?: false }
    val theme: Flow<String> = context.dataStore.data.map { it[THEME] ?: "DARK" }
    val folderSort: Flow<String> = context.dataStore.data.map { it[FOLDER_SORT] ?: "DATE_DESC" }
    val audioSort: Flow<String> = context.dataStore.data.map { it[AUDIO_SORT] ?: "DATE_DESC" }

    suspend fun setPin(pinStr: String?) {
        context.dataStore.edit { if (pinStr == null) it.remove(PIN) else it[PIN] = pinStr }
    }
    
    suspend fun setLockEnabled(enabled: Boolean) {
        context.dataStore.edit { it[LOCK_ENABLED] = enabled }
    }

    suspend fun setTheme(themeStr: String) {
        context.dataStore.edit { it[THEME] = themeStr }
    }

    suspend fun setFolderSort(sort: String) {
        context.dataStore.edit { it[FOLDER_SORT] = sort }
    }

    suspend fun setAudioSort(sort: String) {
        context.dataStore.edit { it[AUDIO_SORT] = sort }
    }
}
