package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey val path: String,
    val customOrder: Int,
    val isHidden: Boolean = false
)

@Entity(tableName = "audio_files")
data class AudioEntity(
    @PrimaryKey val id: Long,
    val customOrder: Int
)
