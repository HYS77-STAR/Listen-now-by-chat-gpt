package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.MainViewModel
import com.example.data.SettingsRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDrawerContent(settingsRepo: SettingsRepository, viewModel: MainViewModel) {
    val scope = rememberCoroutineScope()
    val themeStr by settingsRepo.theme.collectAsState(initial = "DARK")
    val lockEnabled by settingsRepo.lockEnabled.collectAsState(initial = false)
    val pin by settingsRepo.pin.collectAsState(initial = null)
    
    var showPinDialog by remember { mutableStateOf(false) }
    var changePinMode by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(300.dp)
            .padding(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(32.dp))
        
        Text("Theme Setup", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Light")
            Switch(
                checked = themeStr == "DARK",
                onCheckedChange = { isDark ->
                    scope.launch { settingsRepo.setTheme(if (isDark) "DARK" else "LIGHT") }
                },
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            Text("Dark")
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text("App Lock", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Enable PIN Lock")
            Spacer(modifier = Modifier.weight(1f))
            Switch(
                checked = lockEnabled,
                onCheckedChange = { enable ->
                    if (enable) {
                        if (pin == null) {
                            changePinMode = true
                            showPinDialog = true
                        } else {
                            scope.launch { settingsRepo.setLockEnabled(true) }
                        }
                    } else {
                        // User MUST enter current PIN to disable
                        changePinMode = false
                        showPinDialog = true
                    }
                }
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Text(
            "Proudly crafted by HUS",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
    
    if (showPinDialog) {
        if (changePinMode) {
            var newPin by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showPinDialog = false },
                title = { Text("Set 4-Digit PIN") },
                text = {
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { if (it.length <= 4 && it.all { char -> char.isDigit() }) newPin = it },
                        singleLine = true
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        if (newPin.length == 4) {
                            scope.launch { 
                                settingsRepo.setPin(newPin)
                                settingsRepo.setLockEnabled(true)
                            }
                            showPinDialog = false
                        }
                    }) {
                        Text("Save")
                    }
                }
            )
        } else {
            var confirmPin by remember { mutableStateOf("") }
            var error by remember { mutableStateOf(false) }
            
            AlertDialog(
                onDismissRequest = { showPinDialog = false },
                title = { Text("Enter Current PIN") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = confirmPin,
                            onValueChange = { if (it.length <= 4 && it.all { char -> char.isDigit() }) confirmPin = it },
                            singleLine = true,
                            isError = error
                        )
                        if (error) {
                            Text("Incorrect PIN", color = MaterialTheme.colorScheme.error)
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (confirmPin == pin) {
                            scope.launch { settingsRepo.setLockEnabled(false) }
                            showPinDialog = false
                        } else {
                            error = true
                        }
                    }) {
                        Text("Unlock")
                    }
                }
            )
        }
    }
}
