package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.MainViewModel
import com.example.service.AudioService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(viewModel: MainViewModel, navController: NavController) {
    val uiState by viewModel.uiState.collectAsState()
    val currentAudio = uiState.audioFiles.find { it.id == uiState.currentlyPlayingId } ?: return
    
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var activeTimer by remember { mutableStateOf(AudioService.sleepTimerEndTimeMs != null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.Close, "Close")
                    }
                },
                actions = {
                    IconButton(onClick = { showSleepTimerDialog = true }) {
                        Icon(
                            Icons.Default.AccessTime,
                            "Sleep Timer",
                            tint = if (activeTimer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(250.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currentAudio.title.take(1).uppercase(),
                    fontSize = 64.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Text(
                currentAudio.title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 2
            )
            Text(
                currentAudio.folderName,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            FloatingActionButton(
                onClick = { viewModel.togglePlayPause() },
                modifier = Modifier.size(80.dp),
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(
                    if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    modifier = Modifier.size(40.dp)
                )
            }
        }
    }
    
    if (showSleepTimerDialog) {
        if (activeTimer) {
            AlertDialog(
                onDismissRequest = { showSleepTimerDialog = false },
                title = { Text("Sleep Timer Active") },
                text = { Text("A sleep timer is currently running. Do you want to dismiss it?") },
                confirmButton = {
                    Button(onClick = {
                        AudioService.cancelSleepTimer()
                        activeTimer = false
                        showSleepTimerDialog = false
                    }) {
                        Text("Dismiss Timer")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSleepTimerDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        } else {
            var minutesInput by remember { mutableStateOf("") }
            
            ModalBottomSheet(onDismissRequest = { showSleepTimerDialog = false }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Set Sleep Timer", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = if (minutesInput.isEmpty()) "0 min" else "$minutesInput min",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    val dialPad = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("", "0", "DEL")
                    )
                    
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        dialPad.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                row.forEach { digit ->
                                    if (digit.isEmpty()) {
                                        Spacer(modifier = Modifier.size(72.dp))
                                    } else {
                                        Button(
                                            onClick = {
                                                if (digit == "DEL") {
                                                    if (minutesInput.isNotEmpty()) minutesInput = minutesInput.dropLast(1)
                                                } else {
                                                    if (minutesInput.length < 3) {
                                                        val newVal = minutesInput + digit
                                                        if (newVal.toIntOrNull() ?: 0 <= 999) {
                                                            minutesInput = newVal
                                                        }
                                                    }
                                                }
                                            },
                                            modifier = Modifier.size(72.dp),
                                            shape = CircleShape,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        ) {
                                            Text(digit, fontSize = 24.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    Button(
                        onClick = {
                            val mins = minutesInput.toIntOrNull() ?: 0
                            if (mins > 0) {
                                AudioService.setSleepTimer(mins)
                                activeTimer = true
                            }
                            showSleepTimerDialog = false
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text("Start Timer")
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}
