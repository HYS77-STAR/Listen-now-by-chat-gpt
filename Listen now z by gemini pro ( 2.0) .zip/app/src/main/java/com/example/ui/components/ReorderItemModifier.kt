package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun Modifier.reorderItem(
    state: ReorderState,
    index: Int
): Modifier {
    val isDragging = state.draggedIndex == index
    
    val scale by animateFloatAsState(if (isDragging) 1.05f else 1f)
    val shadow by animateFloatAsState(if (isDragging) 8f else 0f)
    
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
            shadowElevation = shadow
        }
        .offset {
            if (isDragging) {
                IntOffset(0, state.dragOffset.roundToInt())
            } else {
                IntOffset.Zero
            }
        }
}
