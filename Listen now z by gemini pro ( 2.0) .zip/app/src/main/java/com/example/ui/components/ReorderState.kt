package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.lazy.LazyListItemInfo
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun rememberReorderState(
    lazyListState: LazyListState,
    onMove: (fromIndex: Int, toIndex: Int) -> Unit,
    onDragEnd: () -> Unit
): ReorderState {
    return remember { ReorderState(lazyListState, onMove, onDragEnd) }
}

class ReorderState(
    val lazyListState: LazyListState,
    val onMove: (Int, Int) -> Unit,
    val onDragEnd: () -> Unit
) {
    var draggedIndex by mutableStateOf<Int?>(null)
        private set
    var dragOffset by mutableStateOf(0f)
        private set

    fun onDragStart(index: Int) {
        draggedIndex = index
        dragOffset = 0f
    }

    fun onDrag(offset: Float) {
        dragOffset += offset
        val draggedIdx = draggedIndex ?: return
        val currentInfo = lazyListState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == draggedIdx } ?: return
        
        val startOffset = currentInfo.offset + dragOffset
        val endOffset = startOffset + currentInfo.size
        
        val hovered = lazyListState.layoutInfo.visibleItemsInfo.firstOrNull {
            it.index != draggedIdx && 
            (startOffset < it.offset + it.size / 2 && endOffset > it.offset + it.size / 2)
        }
        
        if (hovered != null) {
            onMove(draggedIdx, hovered.index)
            draggedIndex = hovered.index
            // Correct the drag offset so the item stays visibly under the finger
            dragOffset -= (hovered.offset - currentInfo.offset)
        }
    }

    fun onDragInterrupted() {
        draggedIndex = null
        dragOffset = 0f
        onDragEnd()
    }
}

fun Modifier.reorderable(
    state: ReorderState,
    index: Int
): Modifier = this
    .pointerInput(Unit) {
        detectDragGesturesAfterLongPress(
            onDragStart = { state.onDragStart(index) },
            onDrag = { change, dragAmount -> 
                change.consume()
                state.onDrag(dragAmount.y)
            },
            onDragEnd = { state.onDragInterrupted() },
            onDragCancel = { state.onDragInterrupted() }
        )
    }
    .zIndex(if (state.draggedIndex == index) 1f else 0f)
