package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkDivider = Color(0xFF2C2C2C)

val FolderAccent = Color(0xFFFFB300)

val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF5F5F5)
val LightDivider = Color(0xFFE0E0E0)

