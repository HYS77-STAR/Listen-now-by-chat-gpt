package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.MainViewModel
import com.example.data.SettingsRepository
import com.example.ui.components.reorderItem
import com.example.ui.components.rememberReorderState
import com.example.ui.components.reorderable
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(
    viewModel: MainViewModel,
    navController: NavController,
    settingsRepo: SettingsRepository
) {
    val uiState by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    
    val allAudio = uiState.audioFiles
    val folders = allAudio
        .map { it.folderName }
        .distinct()
        .filter { !uiState.hiddenFolders.contains(it) }
        
    var sortedFolders by remember(folders, uiState.folderSort, uiState.folderOrders) {
        mutableStateOf(
            when (uiState.folderSort) {
                "ALPHA_ASC" -> folders.sorted()
                "ALPHA_DESC" -> folders.sortedDescending()
                "CUSTOM" -> folders.sortedBy { uiState.folderOrders[it] ?: Int.MAX_VALUE }
                else -> folders
            }
        )
    }
    
    val listState = rememberLazyListState()
    val reorderState = rememberReorderState(
        lazyListState = listState,
        onMove = { from, to ->
            sortedFolders = sortedFolders.toMutableList().apply {
                add(to, removeAt(from))
            }
        },
        onDragEnd = {
            viewModel.setFolderSort("CUSTOM")
            viewModel.saveFoldersOrder(sortedFolders)
        }
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                SettingsDrawerContent(settingsRepo, viewModel)
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Folders") },
                    actions = {
                        var showSortMenu by remember { mutableStateOf(false) }
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(Icons.Default.Sort, "Sort")
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            DropdownMenuItem(text = { Text("Alphabetical (A-Z)") }, onClick = { viewModel.setFolderSort("ALPHA_ASC"); showSortMenu = false })
                            DropdownMenuItem(text = { Text("Alphabetical (Z-A)") }, onClick = { viewModel.setFolderSort("ALPHA_DESC"); showSortMenu = false })
                        }
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Settings, "Settings")
                        }
                    }
                )
            },
            bottomBar = {
                if (uiState.isPlaying || uiState.currentlyPlayingId != null) {
                    PlayerBottomBar(viewModel, navController)
                }
            }
        ) { padding ->
            LazyColumn(
                state = listState,
                contentPadding = padding,
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(sortedFolders, key = { _, item -> item }) { index, folderName ->
                    var showHideOption by remember { mutableStateOf(false) }
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .reorderItem(reorderState, index)
                    ) {
                        ListItem(
                            modifier = Modifier
                                .fillMaxWidth()
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onTap = { navController.navigate("audio_list/$folderName") },
                                        onLongPress = { showHideOption = true }
                                    )
                                },
                            headlineContent = { Text(folderName) },
                            leadingContent = {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            trailingContent = {
                                Icon(
                                    Icons.Default.DragHandle,
                                    contentDescription = "Reorder",
                                    modifier = Modifier.reorderable(reorderState, index)
                                )
                            }
                        )
                        
                        if (showHideOption) {
                            DropdownMenu(
                                expanded = showHideOption,
                                onDismissRequest = { showHideOption = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Hide Folder") },
                                    onClick = { 
                                        viewModel.hideFolder(folderName)
                                        showHideOption = false 
                                    }
                                )
                            }
                        }
                        
                        Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
            }
        }
    }
}
