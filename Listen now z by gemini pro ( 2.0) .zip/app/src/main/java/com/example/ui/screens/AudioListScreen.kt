package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.navigation.NavController
import com.example.MainViewModel
import com.example.ui.components.reorderItem
import com.example.ui.components.rememberReorderState
import com.example.ui.components.reorderable
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioListScreen(
    folderName: String,
    viewModel: MainViewModel,
    navController: NavController
) {
    val uiState by viewModel.uiState.collectAsState()
    
    val folderAudio = uiState.audioFiles.filter { it.folderName == folderName }
    
    var sortedAudio by remember(folderAudio, uiState.audioSort, uiState.audioOrders) {
        mutableStateOf(
            when (uiState.audioSort) {
                "ALPHA_ASC" -> folderAudio.sortedBy { it.title }
                "ALPHA_DESC" -> folderAudio.sortedByDescending { it.title }
                "DATE_ASC" -> folderAudio.sortedBy { it.dateAdded }
                "DATE_DESC" -> folderAudio.sortedByDescending { it.dateAdded }
                "CUSTOM" -> folderAudio.sortedBy { uiState.audioOrders[it.id] ?: Int.MAX_VALUE }
                else -> folderAudio
            }
        )
    }
    
    val listState = rememberLazyListState()
    val reorderState = rememberReorderState(
        lazyListState = listState,
        onMove = { from, to ->
            sortedAudio = sortedAudio.toMutableList().apply {
                add(to, removeAt(from))
            }
        },
        onDragEnd = {
            viewModel.setAudioSort("CUSTOM")
            viewModel.saveAudioOrder(sortedAudio)
        }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(folderName) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    var showSortMenu by remember { mutableStateOf(false) }
                    IconButton(onClick = { showSortMenu = true }) {
                        Icon(Icons.Default.Sort, "Sort")
                    }
                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        DropdownMenuItem(text = { Text("Alphabetical (A-Z)") }, onClick = { viewModel.setAudioSort("ALPHA_ASC"); showSortMenu = false })
                        DropdownMenuItem(text = { Text("Alphabetical (Z-A)") }, onClick = { viewModel.setAudioSort("ALPHA_DESC"); showSortMenu = false })
                        DropdownMenuItem(text = { Text("Date Added (Newest)") }, onClick = { viewModel.setAudioSort("DATE_DESC"); showSortMenu = false })
                        DropdownMenuItem(text = { Text("Date Added (Oldest)") }, onClick = { viewModel.setAudioSort("DATE_ASC"); showSortMenu = false })
                    }
                }
            )
        },
        bottomBar = {
            if (uiState.isPlaying || uiState.currentlyPlayingId != null) {
                PlayerBottomBar(viewModel, navController)
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            contentPadding = padding,
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(sortedAudio, key = { _, item -> item.id }) { index, audio ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .reorderItem(reorderState, index)
                ) {
                    ListItem(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playAudio(audio) },
                        headlineContent = { Text(audio.title, maxLines = 1) },
                        leadingContent = {
                            Icon(Icons.Default.Audiotrack, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
                        },
                        trailingContent = {
                            Icon(
                                Icons.Default.DragHandle,
                                contentDescription = "Reorder",
                                modifier = Modifier.reorderable(reorderState, index)
                            )
                        }
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
    }
}
